import {
  useMemo
} from "react";
import {
  Canvas
} from "@react-three/fiber";
import {
  Bounds,
  OrbitControls
} from "@react-three/drei";
import Pallet from "./Pallet.jsx";
import ProjectPreviewPiece from "./ProjectPreviewPiece.jsx";
import {
  buildPalletizingLayers
} from "../utils/palletizingUtils.js";

export function getProjectPreviewData(
  project
) {
  const layers =
    buildPalletizingLayers(
      project?.palletizingSequence,
      project?.layers
    );

  const hasPalletizing =
    layers.length > 0;

  const pieces = hasPalletizing
    ? layers.flatMap(
        (layer) => layer.pieces
      )
    : Array.isArray(project?.pieces)
      ? project.pieces
      : [];

  const regularPieces =
    pieces.filter(
      (piece) =>
        piece.pieceCategory !==
        "SEPARATOR"
    );

  const modelNames =
    Array.from(
      new Set(
        regularPieces.map(
          (piece) =>
            String(
              piece.name ||
              piece.modelName ||
              `Peça ${
                piece.sourcePieceId ??
                piece.id
              }`
            ).trim()
        )
      )
    ).filter(Boolean);

  return {
    layers,
    pieces,
    regularPieces,
    modelNames,
    hasPalletizing
  };
}

export default function ProjectPalletizingPreview({
  project
}) {
  const previewData =
    useMemo(
      () =>
        getProjectPreviewData(
          project
        ),
      [project]
    );

  if (!project) {
    return (
      <div
        style={{
          height: "235px",
          display: "grid",
          placeItems: "center",
          border: "1px dashed #b8c0c8",
          borderRadius: "7px",
          background: "#f7f8fa",
          color: "#66717c",
          fontSize: "13px"
        }}
      >
        Selecciona un projecte per veure la previsualització.
      </div>
    );
  }

  return (
    <div
      style={{
        height: "330px",
        overflow: "hidden",
        border: "1px solid #d7dce1",
        borderRadius: "7px",
        background: "#eef1f4"
      }}
    >
      <Canvas
        shadows
        camera={{
          position: [
            2600,
            1900,
            2600
          ],
          fov: 38,
          near: 1,
          far: 30000
        }}
      >
        <color
          attach="background"
          args={["#eef1f4"]}
        />

        <ambientLight intensity={1.15} />

        <directionalLight
          castShadow
          position={[
            1500,
            2800,
            1800
          ]}
          intensity={1.45}
        />

        <directionalLight
          position={[
            -1200,
            900,
            -1000
          ]}
          intensity={0.5}
        />

        <Bounds
          fit
          clip
          observe
          margin={1.28}
        >
          <group>
            <Pallet
              pallet={
                project.activePallet
              }
            />

            {previewData.pieces.map(
              (piece, index) => (
                <ProjectPreviewPiece
                  key={
                    piece.id ?? index
                  }
                  piece={piece}
                />
              )
            )}
          </group>
        </Bounds>

        <OrbitControls
          makeDefault
          enablePan={false}
          minDistance={10}
          maxDistance={30000}
        />
      </Canvas>
    </div>
  );
}

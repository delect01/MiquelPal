import { useCallback, useEffect, useState } from "react";
import { PIECE_CONFIG } from "../Config/geometryConfig";
import PiecePreview from "./PiecePreview";
import Import3DButton from "./Import3DButton.jsx";
import { MODEL_BOTTOM_FACES } from "../utils/modelLoader.js";

const STORAGE_KEY = "pallet-simulator-piece-library";

function getInitialForm() {
  return {
    name: "",
    pieceType: "RECTANGULAR",
    width: PIECE_CONFIG.width,
    height: PIECE_CONFIG.height,
    depth: PIECE_CONFIG.depth,
    topWidth: PIECE_CONFIG.topWidth ?? PIECE_CONFIG.width,
    topDepth: PIECE_CONFIG.topDepth ?? PIECE_CONFIG.depth,
    modelId: null,
    modelName: null,
    modelFormat: null,
    modelUnit: null,
    modelBottomFace: "NEGATIVE_Y"
  };
}

function loadSavedPieces() {
  try {
    const value = localStorage.getItem(STORAGE_KEY);
    const parsed = value ? JSON.parse(value) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveLibrary(items) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
}

function Field({ label, value, onChange, type = "text" }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: "5px", fontWeight: 600 }}>
      {label}
      <input
        type={type}
        min={type === "number" ? 1 : undefined}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        style={{ height: "34px", padding: "0 8px", border: "1px solid #aeb6bf", borderRadius: "5px" }}
      />
    </label>
  );
}

export default function NewPieceDialog({ open, onClose, onCreatePiece }) {
  const [form, setForm] = useState(getInitialForm);
  const [savedPieces, setSavedPieces] = useState(loadSavedPieces);
  const [selectedSavedPieceId, setSelectedSavedPieceId] = useState("");
  const [feedback, setFeedback] = useState("");

  useEffect(() => {
    if (!open) return;
    setForm(getInitialForm());
    setSelectedSavedPieceId("");
    setFeedback("");
  }, [open]);

  const imported = form.pieceType === "IMPORTED_3D" && form.modelId;

  const update = (field, value) => {
    setFeedback("");
    setForm((current) => ({ ...current, [field]: value }));
  };

  const handleImportedDimensions = useCallback((dimensions) => {
    setForm((current) => {
      if (current.pieceType !== "IMPORTED_3D") return current;
      return {
        ...current,
        ...dimensions,
        topWidth: dimensions.width,
        topDepth: dimensions.depth
      };
    });
  }, []);

  function validatedData() {
    const numeric = {
      width: Number(form.width),
      height: Number(form.height),
      depth: Number(form.depth),
      topWidth: form.pieceType === "TRAPEZOIDAL" ? Number(form.topWidth) : Number(form.width),
      topDepth: form.pieceType === "TRAPEZOIDAL" ? Number(form.topDepth) : Number(form.depth)
    };

    if (Object.values(numeric).some((value) => !Number.isFinite(value) || value <= 0)) {
      setFeedback("Les dimensions calculades no són vàlides.");
      return null;
    }

    return { ...form, ...numeric, name: form.name.trim() };
  }

  function saveTemplate() {
    const data = validatedData();
    if (!data) return;
    if (!data.name) {
      setFeedback("Has d'escriure un nom abans de guardar la peça.");
      return;
    }

    const existing = savedPieces.find(
      (item) => item.name.toLowerCase() === data.name.toLowerCase()
    );
    const saved = {
      ...data,
      id: existing?.id ?? crypto.randomUUID?.() ?? `${Date.now()}-${Math.random()}`
    };
    const next = existing
      ? savedPieces.map((item) => item.id === existing.id ? saved : item)
      : [...savedPieces, saved];

    setSavedPieces(next);
    saveLibrary(next);
    setSelectedSavedPieceId(saved.id);
    setFeedback(existing ? "La plantilla s'ha actualitzat." : "La plantilla s'ha guardat.");
  }

  function selectTemplate(id) {
    setSelectedSavedPieceId(id);
    const selected = savedPieces.find((item) => item.id === id);
    if (selected) setForm({ ...getInitialForm(), ...selected });
  }

  function deleteTemplate() {
    if (!selectedSavedPieceId) return;
    const next = savedPieces.filter((item) => item.id !== selectedSavedPieceId);
    setSavedPieces(next);
    saveLibrary(next);
    setSelectedSavedPieceId("");
    setForm(getInitialForm());
    setFeedback("La plantilla s'ha eliminat.");
  }

  function createPiece() {
    const data = validatedData();
    if (data) onCreatePiece(data);
  }

  if (!open) return null;

  return (
    <div role="dialog" aria-modal="true" style={{
      position: "fixed", inset: 0, zIndex: 1000,
      background: "rgba(20,25,30,0.72)", display: "flex",
      alignItems: "center", justifyContent: "center", padding: "24px"
    }}>
      <div style={{ width: "min(920px,94vw)", maxHeight: "90vh", overflowY: "auto", background: "white", borderRadius: "10px", padding: "16px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px" }}>
          <div>
            <h2 style={{ margin: 0 }}>Nova peça</h2>
            <div style={{ marginTop: "5px", color: "#59636e" }}>
              Defineix una geometria o importa un model 3D.
            </div>
          </div>
          <button type="button" onClick={onClose} style={{ width: "38px", height: "38px", borderRadius: "50%" }}>×</button>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "minmax(280px,360px) minmax(360px,1fr)", gap: "16px" }}>
          <div>
            <section style={{ padding: "12px", border: "1px solid #d7dce1", borderRadius: "7px", marginBottom: "10px" }}>
              <h3 style={{ marginTop: 0 }}>Biblioteca de peces</h3>
              <select value={selectedSavedPieceId} onChange={(event) => selectTemplate(event.target.value)} style={{ width: "100%", height: "36px" }}>
                <option value="" disabled>Llistat</option>
                {[...savedPieces].sort((a, b) => a.name.localeCompare(b.name, "ca")).map((item) => (
                  <option key={item.id} value={item.id}>{item.name}</option>
                ))}
              </select>
              <div style={{ display: "flex", gap: "8px", marginTop: "10px" }}>
                <button type="button" onClick={deleteTemplate} disabled={!selectedSavedPieceId} style={{ flex: 1 }}>
                  Eliminar plantilla
                </button>
                <Import3DButton
                  onImported={(importedPiece) => {
                    setForm({ ...getInitialForm(), ...importedPiece });
                    setSelectedSavedPieceId("");
                    setFeedback("Model importat. Revisa l'orientació, escriu el nom i crea o guarda la peça.");
                  }}
                />
              </div>
            </section>

            <section style={{ padding: "12px", border: "1px solid #d7dce1", borderRadius: "7px" }}>
              <h3 style={{ marginTop: 0 }}>Característiques</h3>
              <Field label="Nom de la peça" value={form.name} onChange={(value) => update("name", value)} />

              {imported ? (
                <>
                  <label style={{ display: "flex", flexDirection: "column", gap: "5px", fontWeight: 600, marginTop: "12px" }}>
                    Cara inferior de la peça
                    <select
                      value={form.modelBottomFace}
                      onChange={(event) => update("modelBottomFace", event.target.value)}
                      style={{ height: "36px", border: "1px solid #aeb6bf", borderRadius: "5px" }}
                    >
                      {MODEL_BOTTOM_FACES.map((face) => (
                        <option key={face.value} value={face.value}>{face.label}</option>
                      ))}
                    </select>
                  </label>
                  <div style={{ marginTop: "12px", padding: "9px", background: "#eef4fb", borderRadius: "5px", color: "#244d7c" }}>
                    Model: {form.modelName}<br />
                    Dimensions calculades: {Number(form.width).toFixed(2)} × {Number(form.height).toFixed(2)} × {Number(form.depth).toFixed(2)} mm
                  </div>
                </>
              ) : (
                <>
                  <label style={{ display: "flex", flexDirection: "column", gap: "5px", fontWeight: 600, marginTop: "12px" }}>
                    Tipus de peça
                    <select value={form.pieceType} onChange={(event) => update("pieceType", event.target.value)} style={{ height: "36px" }}>
                      <option value="RECTANGULAR">RECTANGULAR</option>
                      <option value="TRAPEZOIDAL">TRAPEZOIDAL</option>
                    </select>
                  </label>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(3,minmax(0,1fr))", gap: "7px", marginTop: "12px" }}>
                    <Field type="number" label="Width" value={form.width} onChange={(value) => update("width", value)} />
                    <Field type="number" label="Height" value={form.height} onChange={(value) => update("height", value)} />
                    <Field type="number" label="Depth" value={form.depth} onChange={(value) => update("depth", value)} />
                    {form.pieceType === "TRAPEZOIDAL" && (
                      <>
                        <Field type="number" label="Top Width" value={form.topWidth} onChange={(value) => update("topWidth", value)} />
                        <Field type="number" label="Top Depth" value={form.topDepth} onChange={(value) => update("topDepth", value)} />
                      </>
                    )}
                  </div>
                </>
              )}

              <button type="button" onClick={saveTemplate} style={{ width: "100%", marginTop: "16px", padding: "10px", background: "#2767c5", color: "white", border: 0, borderRadius: "6px" }}>
                Guardar nom i característiques
              </button>
              {feedback && <div style={{ marginTop: "12px", padding: "9px", background: "#eef4fb", color: "#244d7c" }}>{feedback}</div>}
            </section>
          </div>

          <div>
            <h3 style={{ marginTop: 0 }}>Previsualització 3D</h3>
            <PiecePreview
              {...form}
              onImportedDimensions={handleImportedDimensions}
            />
            <div style={{ marginTop: "10px", color: "#59636e", fontSize: "14px" }}>
              Arrossega per rotar. Per als models importats, selecciona quina cara ha de quedar recolzada al palet.
            </div>
          </div>
        </div>

        <div style={{ display: "flex", justifyContent: "flex-end", gap: "8px", marginTop: "14px", paddingTop: "12px", borderTop: "1px solid #d7dce1" }}>
          <button type="button" onClick={onClose} style={{ padding: "10px 18px" }}>Cancel·lar</button>
          <button type="button" onClick={createPiece} style={{ padding: "10px 22px", background: "#168447", color: "white", border: 0, borderRadius: "6px", fontWeight: 700 }}>
            Crear peça
          </button>
        </div>
      </div>
    </div>
  );
}

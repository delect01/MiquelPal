import * as THREE from "three";
import {
  COLLISION_CONFIG
} from "../Config/geometryConfig";
import {
  getPieceWorldVertices,
  getPieceFaces,
  getPieceEdges
} from "./pieceGeometry";
import {
  getPieceCenter,
  palletEulerToThreeQuaternion
} from "./pieceUtils";

const AXIS_EPSILON = 1e-10;
const PARALLEL_EPSILON = 1e-6;
const DEBUG_INTERVAL_MS = 500;

let lastDebugTime = 0;
let lastDebugSignature = "";

function isImportedPiece(piece) {
  return piece?.pieceType === "IMPORTED_3D";
}

function pairContainsImportedPiece(pieceA, pieceB) {
  return isImportedPiece(pieceA) || isImportedPiece(pieceB);
}

function addUniqueAxis(axes, candidateAxis) {
  if (!candidateAxis || candidateAxis.lengthSq() < AXIS_EPSILON) {
    return;
  }

  const normalizedAxis = candidateAxis.clone().normalize();

  const alreadyExists = axes.some(
    (existingAxis) =>
      Math.abs(existingAxis.dot(normalizedAxis)) >
      1 - PARALLEL_EPSILON
  );

  if (!alreadyExists) {
    axes.push(normalizedAxis);
  }
}

function getFaceNormals(vertices, faces) {
  const normals = [];

  faces.forEach((face) => {
    if (!Array.isArray(face) || face.length < 3) {
      return;
    }

    const pointA = vertices[face[0]];
    const pointB = vertices[face[1]];
    const pointC = vertices[face[2]];

    if (!pointA || !pointB || !pointC) {
      return;
    }

    addUniqueAxis(
      normals,
      new THREE.Vector3().crossVectors(
        pointB.clone().sub(pointA),
        pointC.clone().sub(pointA)
      )
    );
  });

  return normals;
}

function getEdgeDirections(vertices, edges) {
  const directions = [];

  edges.forEach((edge) => {
    if (!Array.isArray(edge) || edge.length < 2) {
      return;
    }

    const startPoint = vertices[edge[0]];
    const endPoint = vertices[edge[1]];

    if (!startPoint || !endPoint) {
      return;
    }

    addUniqueAxis(
      directions,
      endPoint.clone().sub(startPoint)
    );
  });

  return directions;
}

function getSeparatingAxesFromGeometry(
  verticesA,
  facesA,
  edgesA,
  verticesB,
  facesB,
  edgesB
) {
  const axes = [];

  getFaceNormals(verticesA, facesA).forEach(
    (axis) => addUniqueAxis(axes, axis)
  );

  getFaceNormals(verticesB, facesB).forEach(
    (axis) => addUniqueAxis(axes, axis)
  );

  const edgeDirectionsA = getEdgeDirections(verticesA, edgesA);
  const edgeDirectionsB = getEdgeDirections(verticesB, edgesB);

  edgeDirectionsA.forEach((edgeA) => {
    edgeDirectionsB.forEach((edgeB) => {
      addUniqueAxis(
        axes,
        new THREE.Vector3().crossVectors(edgeA, edgeB)
      );
    });
  });

  return axes;
}

function projectVertices(vertices, axis) {
  let minimum = Infinity;
  let maximum = -Infinity;

  vertices.forEach((vertex) => {
    const projection = vertex.dot(axis);
    minimum = Math.min(minimum, projection);
    maximum = Math.max(maximum, projection);
  });

  return { minimum, maximum };
}

function getProjectionGap(projectionA, projectionB) {
  return Math.max(
    projectionB.minimum - projectionA.maximum,
    projectionA.minimum - projectionB.maximum
  );
}

function analyzeGeometry(
  verticesA,
  facesA,
  edgesA,
  verticesB,
  facesB,
  edgesB
) {
  const axes = getSeparatingAxesFromGeometry(
    verticesA,
    facesA,
    edgesA,
    verticesB,
    facesB,
    edgesB
  );

  const axisResults = axes.map((axis, index) => {
    const projectionA = projectVertices(verticesA, axis);
    const projectionB = projectVertices(verticesB, axis);

    return {
      index,
      axis: {
        x: Number(axis.x.toFixed(6)),
        y: Number(axis.y.toFixed(6)),
        z: Number(axis.z.toFixed(6))
      },
      gap: Number(
        getProjectionGap(projectionA, projectionB).toFixed(6)
      ),
      projectionA: {
        minimum: Number(projectionA.minimum.toFixed(6)),
        maximum: Number(projectionA.maximum.toFixed(6))
      },
      projectionB: {
        minimum: Number(projectionB.minimum.toFixed(6)),
        maximum: Number(projectionB.maximum.toFixed(6))
      }
    };
  });

  axisResults.sort((resultA, resultB) => resultB.gap - resultA.gap);

  const maximumGap = axisResults[0]?.gap ?? Infinity;
  const tolerance = Number(COLLISION_CONFIG.tolerance ?? 0);

  return {
    colliding: maximumGap <= tolerance,
    maximumGap,
    tolerance,
    decisiveAxis: axisResults[0] ?? null,
    axisCount: axes.length,
    axes: axisResults
  };
}

function createExplicitBoxVertices(piece) {
  const halfWidth = Number(piece.width) / 2;
  const halfHeight = Number(piece.height) / 2;
  const halfDepth = Number(piece.depth) / 2;

  const localVertices = [
    new THREE.Vector3(-halfWidth, -halfHeight, -halfDepth),
    new THREE.Vector3(halfWidth, -halfHeight, -halfDepth),
    new THREE.Vector3(halfWidth, -halfHeight, halfDepth),
    new THREE.Vector3(-halfWidth, -halfHeight, halfDepth),
    new THREE.Vector3(-halfWidth, halfHeight, -halfDepth),
    new THREE.Vector3(halfWidth, halfHeight, -halfDepth),
    new THREE.Vector3(halfWidth, halfHeight, halfDepth),
    new THREE.Vector3(-halfWidth, halfHeight, halfDepth)
  ];

  const centerData = getPieceCenter(piece);
  const center = new THREE.Vector3(
    centerData.x,
    centerData.y,
    centerData.z
  );

  const quaternion = palletEulerToThreeQuaternion(
    piece.rxDeg,
    piece.ryDeg,
    piece.rzDeg
  );

  return localVertices.map(
    (vertex) => vertex.applyQuaternion(quaternion).add(center)
  );
}

const BOX_FACES = [
  [0, 3, 2, 1],
  [4, 5, 6, 7],
  [0, 1, 5, 4],
  [1, 2, 6, 5],
  [2, 3, 7, 6],
  [3, 0, 4, 7]
];

const BOX_EDGES = [
  [0, 1], [1, 2], [2, 3], [3, 0],
  [4, 5], [5, 6], [6, 7], [7, 4],
  [0, 4], [1, 5], [2, 6], [3, 7]
];

export function getImportedCollisionDiagnostic(pieceA, pieceB) {
  const hullVerticesA = getPieceWorldVertices(pieceA);
  const hullVerticesB = getPieceWorldVertices(pieceB);

  const hullTest = analyzeGeometry(
    hullVerticesA,
    getPieceFaces(pieceA),
    getPieceEdges(pieceA),
    hullVerticesB,
    getPieceFaces(pieceB),
    getPieceEdges(pieceB)
  );

  const boxVerticesA = createExplicitBoxVertices(pieceA);
  const boxVerticesB = createExplicitBoxVertices(pieceB);

  const explicitBoxTest = analyzeGeometry(
    boxVerticesA,
    BOX_FACES,
    BOX_EDGES,
    boxVerticesB,
    BOX_FACES,
    BOX_EDGES
  );

  return {
    pair: `${pieceA.id}:${pieceB.id}`,
    pieceA: {
      id: pieceA.id,
      pieceType: pieceA.pieceType,
      hullVertexCount: hullVerticesA.length,
      storedCollisionVertexCount:
        pieceA.collisionGeometry?.vertices?.length ?? 0,
      dimensions: {
        width: pieceA.width,
        height: pieceA.height,
        depth: pieceA.depth
      }
    },
    pieceB: {
      id: pieceB.id,
      pieceType: pieceB.pieceType,
      hullVertexCount: hullVerticesB.length,
      storedCollisionVertexCount:
        pieceB.collisionGeometry?.vertices?.length ?? 0,
      dimensions: {
        width: pieceB.width,
        height: pieceB.height,
        depth: pieceB.depth
      }
    },
    realHullTest: hullTest,
    explicitBoxTest,
    sameCollisionResult:
      hullTest.colliding === explicitBoxTest.colliding,
    gapDifference:
      Number(
        (hullTest.maximumGap - explicitBoxTest.maximumGap)
          .toFixed(6)
      )
  };
}

function maybeLogImportedDiagnostic(pieceA, pieceB, result) {
  if (!pairContainsImportedPiece(pieceA, pieceB)) {
    return;
  }

  const now = performance.now();
  const signature = [
    pieceA.id,
    pieceB.id,
    Number(pieceA.x).toFixed(3),
    Number(pieceA.y).toFixed(3),
    Number(pieceA.z).toFixed(3),
    Number(pieceB.x).toFixed(3),
    Number(pieceB.y).toFixed(3),
    Number(pieceB.z).toFixed(3),
    result.realHullTest.colliding,
    result.explicitBoxTest.colliding
  ].join("|");

  if (
    signature === lastDebugSignature &&
    now - lastDebugTime < DEBUG_INTERVAL_MS
  ) {
    return;
  }

  lastDebugSignature = signature;
  lastDebugTime = now;

  console.groupCollapsed(
    `[IMPORTED_COLLISION_DIAGNOSTIC] ${pieceA.id} vs ${pieceB.id}`
  );
  console.log("RESUM", {
    hullColliding: result.realHullTest.colliding,
    hullGap: result.realHullTest.maximumGap,
    boxColliding: result.explicitBoxTest.colliding,
    boxGap: result.explicitBoxTest.maximumGap,
    sameCollisionResult: result.sameCollisionResult,
    gapDifference: result.gapDifference
  });
  console.log("GEOMETRIA REAL", result.realHullTest);
  console.log("CAIXA EXPLICITA", result.explicitBoxTest);
  console.log("PECES", {
    pieceA: result.pieceA,
    pieceB: result.pieceB
  });
  console.groupEnd();
}

export function arePiecesPreciselyColliding(pieceA, pieceB) {
  const diagnostic = getImportedCollisionDiagnostic(pieceA, pieceB);

  if (pairContainsImportedPiece(pieceA, pieceB)) {
    maybeLogImportedDiagnostic(pieceA, pieceB, diagnostic);
    return diagnostic.realHullTest.colliding;
  }

  return diagnostic.realHullTest.colliding;
}

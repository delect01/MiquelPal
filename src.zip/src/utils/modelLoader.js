import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { STLLoader } from "three/examples/jsm/loaders/STLLoader.js";
import { getImportedModel } from "./modelStorage.js";
import { buildImportedCollisionGeometry } from "./importedGeometry.js";

const UNIT_SCALE = { mm: 1, cm: 10, m: 1000 };
const sourceCache = new Map();

export const MODEL_BOTTOM_FACES = [
  { value: "NEGATIVE_Y", label: "Cara inferior actual (-Y)" },
  { value: "POSITIVE_Y", label: "Cara superior actual (+Y)" },
  { value: "NEGATIVE_X", label: "Cara esquerra actual (-X)" },
  { value: "POSITIVE_X", label: "Cara dreta actual (+X)" },
  { value: "NEGATIVE_Z", label: "Cara posterior actual (-Z)" },
  { value: "POSITIVE_Z", label: "Cara frontal actual (+Z)" }
];

const SOURCE_FACE_DIRECTIONS = {
  NEGATIVE_X: new THREE.Vector3(-1, 0, 0),
  POSITIVE_X: new THREE.Vector3(1, 0, 0),
  NEGATIVE_Y: new THREE.Vector3(0, -1, 0),
  POSITIVE_Y: new THREE.Vector3(0, 1, 0),
  NEGATIVE_Z: new THREE.Vector3(0, 0, -1),
  POSITIVE_Z: new THREE.Vector3(0, 0, 1)
};

const WORLD_DOWN = new THREE.Vector3(0, -1, 0);

function getFormat(name) {
  const extension = name.split(".").pop()?.toLowerCase();
  if (extension === "glb" || extension === "stl") return extension;
  throw new Error("Format no compatible. Utilitza .glb o .stl.");
}

function parseGlb(buffer) {
  return new Promise((resolve, reject) => {
    new GLTFLoader().parse(buffer, "", (gltf) => resolve(gltf.scene), reject);
  });
}

function parseStl(buffer) {
  const geometry = new STLLoader().parse(buffer);
  geometry.computeVertexNormals();
  return new THREE.Mesh(
    geometry,
    new THREE.MeshStandardMaterial({
      color: "#f28c28",
      roughness: 0.58,
      metalness: 0
    })
  );
}

function cloneMaterials(object) {
  object.traverse((child) => {
    if (!child.isMesh) return;
    child.castShadow = true;
    child.receiveShadow = true;
    if (Array.isArray(child.material)) {
      child.material = child.material.map((material) => material.clone());
    } else if (child.material) {
      child.material = child.material.clone();
    }
  });
}

function getSelectedSupportFace(collisionGeometry, bottomFace) {
  const requestedDirection =
    SOURCE_FACE_DIRECTIONS[bottomFace] ?? SOURCE_FACE_DIRECTIONS.NEGATIVE_Y;

  let bestFace = null;
  let bestDot = -Infinity;

  collisionGeometry.faces.forEach((face) => {
    const normal = new THREE.Vector3(
      Number(face.normal?.x ?? 0),
      Number(face.normal?.y ?? 0),
      Number(face.normal?.z ?? 0)
    );

    if (normal.lengthSq() < Number.EPSILON) return;
    normal.normalize();

    const dot = normal.dot(requestedDirection);
    if (dot > bestDot) {
      bestDot = dot;
      bestFace = { ...face, normal };
    }
  });

  return bestFace;
}

function orientSelectedFaceToFloor(object, bottomFace) {
  object.updateMatrixWorld(true);

  const provisionalCollisionGeometry =
    buildImportedCollisionGeometry(object);

  const selectedFace = getSelectedSupportFace(
    provisionalCollisionGeometry,
    bottomFace
  );

  if (!selectedFace) {
    throw new Error("No s'ha pogut identificar la cara inferior del model.");
  }

  const alignmentQuaternion = new THREE.Quaternion()
    .setFromUnitVectors(selectedFace.normal, WORLD_DOWN)
    .normalize();

  object.quaternion.premultiply(alignmentQuaternion);
  object.updateMatrixWorld(true);
}

function getCollisionGeometryBounds(collisionGeometry) {
  const points = collisionGeometry.vertices.map(
    (vertex) => new THREE.Vector3(
      Number(vertex.x),
      Number(vertex.y),
      Number(vertex.z)
    )
  );

  const box = new THREE.Box3().setFromPoints(points);

  return {
    center: box.getCenter(new THREE.Vector3()),
    size: box.getSize(new THREE.Vector3())
  };
}

function centerOrientedObject(object) {
  /*
    La mida i el centre provenen exclusivament de la mateixa
    geometria visible que utilitzen el SAT i l'iman.
    No fem servir Box3.setFromObject(), perquè podria incloure
    meshes auxiliars o límits rectangulars ocults del GLB.
  */
  object.updateMatrixWorld(true);

  const orientedCollisionGeometry =
    buildImportedCollisionGeometry(object);

  const { center, size } =
    getCollisionGeometryBounds(orientedCollisionGeometry);

  object.position.sub(center);
  object.updateMatrixWorld(true);

  return {
    width: size.x,
    height: size.y,
    depth: size.z
  };
}

function prepareObject(source, unit, bottomFace) {
  const root = new THREE.Group();
  const object = source.clone(true);

  cloneMaterials(object);
  object.scale.multiplyScalar(UNIT_SCALE[unit] ?? 1);
  object.updateMatrixWorld(true);

  orientSelectedFaceToFloor(object, bottomFace);
  const dimensions = centerOrientedObject(object);

  root.add(object);
  root.updateMatrixWorld(true);

  const collisionGeometry = buildImportedCollisionGeometry(root);

  return { object: root, dimensions, collisionGeometry };
}

async function parseBlob(blob, format) {
  const buffer = await blob.arrayBuffer();
  return format === "glb" ? parseGlb(buffer) : parseStl(buffer);
}

export async function inspectModelFile(
  file,
  unit = "mm",
  bottomFace = "NEGATIVE_Y"
) {
  const format = getFormat(file.name);
  const source = await parseBlob(file, format);
  return { format, ...prepareObject(source, unit, bottomFace) };
}

async function getSource(modelId) {
  if (sourceCache.has(modelId)) return sourceCache.get(modelId);

  const record = await getImportedModel(modelId);
  if (!record) throw new Error("No s'ha trobat el model 3D desat.");

  const source = await parseBlob(record.blob, record.format);
  const value = { source, record };
  sourceCache.set(modelId, value);
  return value;
}

export async function loadStoredModel(
  modelId,
  bottomFace = "NEGATIVE_Y"
) {
  const { source, record } = await getSource(modelId);
  return prepareObject(source, record.unit, bottomFace);
}

export function clearModelMemoryCache(modelId = null) {
  if (modelId) sourceCache.delete(modelId);
  else sourceCache.clear();
}

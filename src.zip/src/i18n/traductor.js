export const SUPPORTED_LANGUAGES = [
  {
    code: "ca",
    label: "Català",
    direction: "ltr"
  },
  {
    code: "es",
    label: "Castellano",
    direction: "ltr"
  },
  {
    code: "en",
    label: "English",
    direction: "ltr"
  },
  {
    code: "fr",
    label: "Français",
    direction: "ltr"
  },
  {
    code: "ar",
    label: "العربية",
    direction: "rtl"
  }
];

const translations = {
  ca: {
    project: {
      unnamed: "Projecte sense nom",
      recovered: "Projecte recuperat",
      saved: "Projecte guardat",
      unsavedChanges: "Canvis sense guardar",
      newTitle: "Crear un projecte nou",
      newDiscardMessage:
        "Hi ha canvis sense guardar. Si continues, la composició actual es descartarà.",
      openTitle: "Obrir un altre projecte",
      openDiscardMessage:
        "Hi ha canvis sense guardar. Si continues, la composició actual es descartarà.",
      discardAndContinue: "Descartar i continuar",
      discardAndOpen: "Descartar i obrir",
      saveError: "No s'ha pogut guardar el projecte.",
      saveNameRequired: "Escriu un nom per al projecte.",
      previousSession:
        "S'ha trobat una sessió anterior sense guardar. Vols recuperar-la?",
      copySuffix: "còpia"
    },
    configurators: {
      gripper: "Configurador gripper",
      pallet: "Configurador palet",
      pieces: "Configurador peces",
      separators: "Configurador separadors",
      layers: "Configurador capes",
      palletizing: "Configurador paletitzat"
    },
    pieces: {
      title: "CONFIGURADOR PECES",
      new: "Nova peça",
      duplicate: "Duplicar",
      delete: "Eliminar",
      selected: "PEÇA SELECCIONADA",
      defaultName: "Peça",
      position: "Posició peça"
    },
    separators: {
      title: "CONFIGURADOR SEPARADORS",
      new: "Nou separador",
      selected: "SEPARADOR SELECCIONAT",
      defaultName: "Separador",
      position: "Posició separador"
    },
    selection: {
      groupMove:
  "Desplaçament del grup",

      groupMoveHelp:
      "Introdueix un desplaçament en mil·límetres. Els valors s'aplicaran a tots els elements seleccionats.",
      multipleTitle: "SELECCIÓ MÚLTIPLE",
      selectedElements: "elements seleccionats",
      help:
        "Arrossega qualsevol element seleccionat per moure tot el grup. Prem Supr per eliminar la selecció."
    },



    
    reference: {
      robotTcp: "Referència TCP Robot",
      contactFace: "Cara contacte",
      orientation: "Orientació referència",
      faceOffsetX: "Face Offset X",
      faceOffsetY: "Face Offset Y",
      faceRotation: "Face Rotation",
      refRx: "Ref RX",
      refRy: "Ref RY",
      refRz: "Ref RZ"
    },
    layer: {
      deleteTitle: "Eliminar capa",
      deleteQuestion: (name) =>
        `Estàs segur que vols eliminar la capa "${name}"?`,
      defaultName: (number) => `Capa ${number}`,
      idErrorTitle: "No es pot guardar la capa",
      idCorrection:
        "Corregeix els ID i torna-ho a provar.",
      idConsecutive: (maximum) =>
        `Els ID han de ser consecutius de l'1 al ${maximum}.`,
      idEmpty: (count) =>
        `${count} element(s) sense ID.`,
      idInvalid: (count) =>
        `${count} element(s) amb un ID que no és un enter positiu.`,
      idDuplicate: (count) =>
        `${count} element(s) comparteixen un ID duplicat.`
    },
    common: {
      id: "ID",
      name: "Nom",
      yes: "Sí",
      no: "No",
      accept: "Acceptar",
      confirm: "Confirmar",
      cancel: "Cancel·lar",
      x: "X",
      y: "Y",
      z: "Z",
      rx: "RX",
      ry: "RY",
      rz: "RZ"
    },
    language: {
      change: "Canviar idioma",
      internalJokeLink:
        "https:/ www.amazon.es/diccionario-catalan-castellano/s?k=diccionario+catalan+castellano"
    }
  },
  es: {
    project: {
      unnamed: "Proyecto sin nombre",
      recovered: "Proyecto recuperado",
      saved: "Proyecto guardado",
      unsavedChanges: "Cambios sin guardar"
    },
    configurators: {
      gripper: "Configurador de pinza",
      pallet: "Configurador de palé",
      pieces: "Configurador de piezas",
      separators: "Configurador de separadores",
      layers: "Configurador de capas",
      palletizing: "Configurador de paletizado"
    }
  },
  en: {
    project: {
      unnamed: "Untitled project",
      recovered: "Recovered project",
      saved: "Project saved",
      unsavedChanges: "Unsaved changes"
    },
    configurators: {
      gripper: "Gripper configurator",
      pallet: "Pallet configurator",
      pieces: "Piece configurator",
      separators: "Separator configurator",
      layers: "Layer configurator",
      palletizing: "Palletizing configurator"
    }
  },
  fr: {
    project: {
      unnamed: "Projet sans nom",
      recovered: "Projet récupéré",
      saved: "Projet enregistré",
      unsavedChanges: "Modifications non enregistrées"
    },
    configurators: {
      gripper: "Configurateur de préhenseur",
      pallet: "Configurateur de palette",
      pieces: "Configurateur de pièces",
      separators: "Configurateur de séparateurs",
      layers: "Configurateur de couches",
      palletizing: "Configurateur de palettisation"
    }
  },
  ar: {
    project: {
      unnamed: "مشروع بدون اسم",
      recovered: "مشروع مستعاد",
      saved: "تم حفظ المشروع",
      unsavedChanges: "تغييرات غير محفوظة"
    },
    configurators: {
      gripper: "إعداد القابض",
      pallet: "إعداد المنصة",
      pieces: "إعداد القطع",
      separators: "إعداد الفواصل",
      layers: "إعداد الطبقات",
      palletizing: "إعداد الرص على المنصة"
    }
  }
};

function mergeTranslations(baseValue, overrideValue) {
  if (
    typeof baseValue !== "object" ||
    baseValue === null ||
    Array.isArray(baseValue)
  ) {
    return overrideValue ?? baseValue;
  }

  const result = {
    ...baseValue
  };

  Object.keys(overrideValue ?? {}).forEach((key) => {
    result[key] = mergeTranslations(
      baseValue[key],
      overrideValue[key]
    );
  });

  return result;
}

export function getTranslator(languageCode = "ca") {
  const selectedTranslations =
    translations[languageCode] ??
    translations.ca;

  return mergeTranslations(
    translations.ca,
    selectedTranslations
  );
}

export function getLanguageDirection(languageCode = "ca") {
  return (
    SUPPORTED_LANGUAGES.find(
      (language) =>
        language.code === languageCode
    )?.direction ?? "ltr"
  );
}

export default translations;
